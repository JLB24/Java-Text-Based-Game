import java.util.Scanner;

public class Level extends GameLogic {

  // MakeScanner
  public static Scanner UI = new Scanner(System.in);

  public static void StoryIntro() throws Exception {
    
    System.out.println("┏━━┓");
    System.out.println("┃┏━╋━┓┏━━┳━┓");
    System.out.println("┃┗┓┃╋┗┫┃┃┃┻┫");
    System.out.println("┗━━┻━━┻┻┻┻━┛");

    Util.TextSpace();

    System.out.println("You have been out at sea for weeks, traveling the unknown seas for as long as you remember On the Horizon see a island; after docking your ship you are surrounded by trees in all directions.");

    Util.TextSpace();

    Story();
  }

  public static void Story() throws Exception {
    String input;
    
    System.out.println("Would you like to venture back into the forest? (Y/N)");
    input = UI.nextLine();
    if (input.equals("Y")){
      
      Util.TextSpace();
      System.out.println("You wander the forest for weeks in search for who knows what eventually you are unable to find enough food to survive and succumb tho the elements");
      
    }
    else if (input.equals("N")){
      
    Util.TextSpace();
    System.out.println(GameLogic.userHealth + " is your current health. " + GameLogic.userMaxHealth + " is your maximum health currently.");

    Util.TextSpace();
    System.out.println("You walk to the village to rest for a while.\n The local tavern costs 2 gold pieces to stay the night,you can go to the market and browse various shops. Or you can\n also see the steeple of a local church nearby, with it's high towers easily being the most noticeable object \nin the vicinity.");
      
    System.out.println("\nWhere will you go? (Tavern/Church)");
    input = UI.nextLine();
      if (input.equals("Tavern")){
        System.out.println("The tavern is bustling with the local folk. \nThey offer drinks for one gold piece and rooms for two gold pieces. One of the innkeepers asks how they can help you. \n(Drink/Sleep)");
        input = UI.nextLine();
          if (input.equals("Drink")){
            System.out.println("You stop at the bar and grab yourself a stein \nof rum to drink.\nYou now have a stomach full of joy");
          
            System.out.println("The rum is especially good tonight. Warmth \nfills your veins and you feel renewed with energy and vigor.");
            
            System.out.println(GameLogic.userHealth + " is your current health, " + GameLogic.userMaxHealth + " is your maximum health currently.");

            Story();
          }
          if (input.equals("Sleep")){
            System.out.println("You stay the night at the Tavern; Your health is fully restored. Your health returns to " + GameLogic.userMaxHealth + " health.");
            
          GameLogic.userHealth = GameLogic.userMaxHealth;

            Story();
          }
          else {
      System.out.println("Please Enter a Valid Action");
      Thread.sleep(2000);
      Story();
    }
      }
      else if (input.equals("Church")){

      System.out.println("The church is abandoned. The floor is covered in dust, \nthe windows borded up, and there is no evidence of anyone having been there in years.");
        
      System.out.println("You enter the modest village church, with a few small \nwooden benches and stools scattered around.\nYou see an elderly man in dark robes kneeling before an altar to a god \nWithout turning around, he asks what you seek here.Health? He asks. (Y/N)");
      input = UI.nextLine();
        if (input.equals("Y")){
          System.out.println("I can aid you in that, with powers deemed unnatural\n by some. But this does not come without a price. Do you agree to this?(Y/N)");
          if (input.equals("Y")){
            
            System.out.println("There you are. Go now; and reap the benefits of \nyour increased fortitude");
            
            GameLogic.userHealth = GameLogic.userMaxHealth;
            
            System.out.println(GameLogic.userHealth + " is your current health. " + GameLogic.userMaxHealth + " is your maximum health currently.");

            Story();
          }
          else if (input.equals("N")){
          
            System.out.println("Then please, leave me to my work.");

            Story();
          }
          else {
            System.out.println("Please Enter a Valid Action");
            Thread.sleep(2000);
            Story();
          }
        }
        else if (input.equals("N")){
          
          System.out.println("Then please, leave me to my work.");

          Story();
          }
        else {
      System.out.println("Please Enter a Valid Action");
      Thread.sleep(2000);
      Story();
    }
      }
      else {
      System.out.println("Please Enter a Valid Action");
      Thread.sleep(2000);
      Story();
    }
    }
    else {
      System.out.println("Please Enter a Valid Action");
      Thread.sleep(2000);
      Story();
    }
  }
  
}