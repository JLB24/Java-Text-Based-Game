public class Util {
  
  // TextHelpers
  public static void TextTriSpace() throws Exception {
    for (int i = 0; i < 3; i++) {
      System.out.println("");
    }
  }

  public static void TextSpace() throws Exception {
    for (int i = 0; i < 1; i++) {
      System.out.println("");
    }
  }

  public static void TextLine() throws Exception {
    for (int i = 0; i < 1; i++) {
      System.out.println("");
      System.out.println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
      System.out.println("");

    }
  }
  
}