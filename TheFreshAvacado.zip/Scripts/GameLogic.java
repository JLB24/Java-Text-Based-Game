import java.util.Scanner;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;

public class GameLogic {

  // MakeScanner
  public static Scanner UI = new Scanner(System.in);

  // UserStuffs
  public static String userName;
  public static String userType;

  public static String userClass;
  public static String userWeapon;
  public static String userArmor;

  public static int userHealth;
  public static int userMaxHealth;
  public static int userBaseAttack;
  public static int userCharizma;
  public static int userStrength;

  // SaveSlots
  public static int isUser1 = 1;
  public static int isUser2 = 1;
  public static int isUser3 = 1;

  // SaveSlotChoose
  public static String whatSave;
  
  //━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  
  public static void BootGame() throws Exception {
    String input;

    // Intro

    Util.TextLine();

    System.out.println("┏┓┏┓┏┓╋╋┏┓╋╋╋╋╋╋╋╋╋╋╋╋╋ ┏┓╋┏┓");
    System.out.println("┃┃┃┃┃┃╋╋┃┃╋╋╋╋╋╋╋╋╋╋╋╋╋ ┃┃╋┃┃");
    System.out.println("┃┃┃┃┃┣━━┫┃┏━━┳━━┳┓┏┳━━┓ ┃┃╋┃┣━━┳━━┳━┓");
    System.out.println("┃┗┛┗┛┃┃━┫┃┃┏━┫┏┓┃┗┛┃┃━┫ ┃┃╋┃┃━━┫┃━┫┏┛");
    System.out.println("┗┓┏┓┏┫┃━┫┗┫┗━┫┗┛┃┃┃┃┃━┫ ┃┗━┛┣━━┃┃━┫┃");
    System.out.println("╋┗┛┗┛┗━━┻━┻━━┻━━┻┻┻┻━━┛ ┗━━━┻━━┻━━┻┛");

    Util.TextLine();

    System.out.println("");
    System.out.println("Press Enter to Continue");
    input = UI.nextLine();
    if (input.equals("")) {
      SaveSelect();
    }
    else {
      System.out.println("Please Enter a Valid Action");
      Thread.sleep(2000);
      BootGame();
    }

  }

  public static void SaveSelect() throws Exception {
    String input;

    // UserSelect
    Util.TextLine();

    System.out.println("┏┓╋╋╋╋╋╋┏┓ ╋╋╋╋╋ ┏━┓╋╋╋╋╋╋┏┓╋╋╋ ┏━━┓");
    System.out.println("┃┃┏━┳━┓┏┛┃ ┏━┳┳┓ ┃┏╋┳┳━┳━┓┃┗┳━┓ ┃━━╋━┳━┳━┳━┓");
    System.out.println("┃┗┫╋┃╋┗┫╋┃ ┃╋┃┏┛ ┃┗┫┏┫┻┫╋┗┫┏┫┻┫ ┣━━┃╋┗┓┃┏┫┻┫");
    System.out.println("┗━┻━┻━━┻━┛ ┗━┻┛╋ ┗━┻┛┗━┻━━┻━┻━┛ ┗━━┻━━┻━┛┗━┛");

    Util.TextLine();

    ArrayList<String> saveFiles = new ArrayList<String>();

    saveFiles.add("1");
    saveFiles.add("2");
    saveFiles.add("3");

    System.out.println("Please Select Save Slot");
    System.out.println(saveFiles);

    input = UI.nextLine();
    if (input.equals("1")) {

      whatSave = "Save1.txt";

      System.out.println("New Game or Continue Game \n[New, Continue]");
      input = UI.nextLine();
      if (input.equals("New")) {
        Util.TextSpace();
        System.out.println("Save 1 Created");
        Util.TextSpace();
        NewUser();
      } else if (input.equals("Continue")) {
        Util.TextSpace();
        System.out.println("Save 1 Loaded");
        Util.TextSpace();
        LoadData();
      }
    } 
    else if (input.equals("2")) {

      whatSave = "Save2.txt";

      System.out.println("New Game or Continue Game \n[New, Continue]");
      input = UI.nextLine();
      if (input.equals("New")) {
        Util.TextSpace();
        System.out.println("Save 2 Created");
        Util.TextSpace();
        NewUser();
      } else if (input.equals("Continue")) {
        Util.TextSpace();
        System.out.println("Save 2 Loaded");
        Util.TextSpace();
        LoadData();
      }
    } 
    else if (input.equals("3")) {

      whatSave = "Save3.txt";

      System.out.println("New Game or Continue Game \n[New, Continue]");
      input = UI.nextLine();
      if (input.equals("New")) {
        Util.TextSpace();
        System.out.println("Save 3 Created");
        Util.TextSpace();
        NewUser();
      } else if (input.equals("Continue")) {
        Util.TextSpace();
        System.out.println("Save 3 Loaded");
        Util.TextSpace();
        LoadData();
      }
    } 
    else {
      System.out.println("Please Enter a Valid Action");
      Thread.sleep(2000);
      SaveSelect();
    }
  }
  
  //━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  
  public static void LoadData() throws Exception {

    try {
      BufferedReader br = new BufferedReader(new FileReader("Saves/" + whatSave));

      userName = br.readLine();
      userType = br.readLine();
      userClass = br.readLine();
      userWeapon = br.readLine();
      userArmor = br.readLine();

      userHealth = Integer.parseInt(br.readLine());
      userMaxHealth = Integer.parseInt(br.readLine());
      userBaseAttack = Integer.parseInt(br.readLine());
      userCharizma = Integer.parseInt(br.readLine());
      userStrength = Integer.parseInt(br.readLine());

      br.close();
    } catch (Exception e) {

    }

    // For Testing

    // System.out.println(userName + userType + userClass + userWeapon + userArmor);
    // System.out.println(userHealth + userMaxHealth + userBaseAttack + userCharizma
    // + userStrength);

    ConfirmLoadUserStat();
  }

  public static void ConfirmLoadUserStat() throws Exception{
    String input;

    System.out.println("Are you sure You want to load User:");


    ArrayList<String> UserStrStat = new ArrayList<String>();

    UserStrStat.add(userName);
    UserStrStat.add(userType);

    UserStrStat.add(userClass);
    UserStrStat.add(userWeapon);
    UserStrStat.add(userArmor);
    
    System.out.println("");
    System.out.println(UserStrStat);

    ArrayList<Integer> UserIntStat = new ArrayList<Integer>();

    UserIntStat.add(userHealth);
    UserIntStat.add(userMaxHealth);
    UserIntStat.add(userBaseAttack);
    UserIntStat.add(userCharizma);
    UserIntStat.add(userStrength);

    System.out.println(UserIntStat);
    System.out.println("");
    System.out.println("[Y, N]");
    
    input = UI.nextLine();
    if (input.equals("Y")) {
      Util.TextLine();
      LoadStartGame();
    }
    else if (input.equals("N")) {
      SaveSelect();
    }
    else {
      System.out.println("Please Enter a Valid Action");
      Thread.sleep(2000);
      BootGame();
    }
  }

  public static void LoadStartGame() throws Exception {

    Level.Story();

  }
  
  //━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  
  public static void NewUser() throws Exception {
    String input;

    // NewUserEdit
    System.out.println("Enter Your Name");
    userName = UI.nextLine();

    Util.TextSpace();

    ArrayList<String> EntType = new ArrayList<String>();

    EntType.add("Human");
    EntType.add("Goblin");
    EntType.add("Elf");

    System.out.println("Enter your Type");
    System.out.println(EntType);

    input = UI.nextLine();
    if (input.equals("Human")) {
      // setBaseHealth
      userMaxHealth = (50);
      // setBaseAttack
      userBaseAttack = (12);
      // SetCharizma
      userCharizma = (10);
      // SetStrength
      userStrength = (15);
      // SetType
      userType = ("Human");
    } 
    else if (input.equals("Goblin")) {
      // setBaseHealth
      userMaxHealth = (40);
      // setBaseAttack
      userBaseAttack = (18);
      // SetCharizma
      userCharizma = (5);
      // SetStrength
      userStrength = (8);
      // SetType
      userType = ("Goblin");
    } 
    else if (input.equals("Elf")) {
      // setBaseHealth
      userMaxHealth = (40);
      // setBaseAttack
      userBaseAttack = (10);
      // SetCharizma
      userCharizma = (15);
      // SetStrength
      userStrength = (10);
      // SetType
      userType = ("Elf");
    } 
    else {
      System.out.println("Please Enter a Valid Action");
      Thread.sleep(2000);
      NewUser();
    }

    Util.TextSpace();

    System.out.println("Enter your Class");
    System.out.println("[Warrior, Hunter, Mage]");

    input = UI.nextLine();
    if (input.equals("Warrior")) {
      // SetClass
      userClass = ("Warrior");
      // SetWeapon
      userWeapon = ("Sword");
      // SetArmor
      userArmor = ("Pesant Garmits");
    } 
    else if (input.equals("Hunter")) {
      // SetClass
      userClass = ("Hunter");
      // SetWeapon
      userWeapon = ("Knife");
      // SetArmor
      userArmor = ("Pesant Garmits");
    } 
    else if (input.equals("Mage")) {
      // SetClass
      userClass = ("Mage");
      // SetWeapon
      userWeapon = ("Staff");
      // SetArmor
      userArmor = ("Pesant Garmits");
    } 
    else {
      System.out.println("Please Enter a Valid Action");
      Thread.sleep(2000);
      NewUser();
    }

    Util.TextSpace();

    System.out.println("You are destined to be a powerfull " + userClass);
    System.out.println("Let your will never falter " + userName);

    Util.TextLine();

    //For Testing
    //System.out.println(whatSave);

    ConfirmNewUserStat();
  }

  public static void ConfirmNewUserStat() throws Exception{
    String input;

    System.out.println("Are you sure you want to create New User:");


    ArrayList<String> UserStrStat = new ArrayList<String>();

    UserStrStat.add(userName);
    UserStrStat.add(userType);

    UserStrStat.add(userClass);
    UserStrStat.add(userWeapon);
    UserStrStat.add(userArmor);
    
    System.out.println("");
    System.out.println(UserStrStat);

    ArrayList<Integer> UserIntStat = new ArrayList<Integer>();

    UserIntStat.add(userHealth);
    UserIntStat.add(userMaxHealth);
    UserIntStat.add(userBaseAttack);
    UserIntStat.add(userCharizma);
    UserIntStat.add(userStrength);

    System.out.println(UserIntStat);
    System.out.println("");
    System.out.println("[Y, N]");
    
    input = UI.nextLine();
    if (input.equals("Y")) {
      Util.TextLine();
      SaveData();
    }
    else if (input.equals("N")) {
      SaveSelect();
    }
    else {
      System.out.println("Please Enter a Valid Action");
      Thread.sleep(2000);
      BootGame();
    }
  }

  public static void SaveData() throws Exception {

    try {
      BufferedWriter bw = new BufferedWriter(new FileWriter("Saves/" + whatSave));

      bw.flush();

      bw.write(userName);
      bw.newLine();
      bw.write(userType);
      bw.newLine();
      bw.write(userClass);
      bw.newLine();
      bw.write(userWeapon);
      bw.newLine();
      bw.write(userArmor);
      bw.newLine();

      bw.write("" + userHealth);
      bw.newLine();
      bw.write("" + userMaxHealth);
      bw.newLine();
      bw.write("" + userBaseAttack);
      bw.newLine();
      bw.write("" + userCharizma);
      bw.newLine();
      bw.write("" + userStrength);

      bw.close();
    }

    catch (Exception e) {

    }

    // For Testing

    // System.out.println(userName + userType + userClass + userWeapon + userArmor);
    // System.out.println(userHealth + userMaxHealth + userBaseAttack + userCharizma
    // + userStrength);

    StoryStartup();
  }

  public static void StoryStartup() throws Exception {

    userMaxHealth = userStrength + userMaxHealth;

    userHealth = GameLogic.userMaxHealth;
    
    userBaseAttack = userStrength + userBaseAttack;

    NewStartGame();
  }

  public static void NewStartGame() throws Exception {

    Level.StoryIntro();

  }

}